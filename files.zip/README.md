# AI Web Asistanı

Claude API kullanarak web sitesine entegre edilebilen basit bir sohbet asistanı. Express backend + vanilla JS frontend.

## Kurulum

1. Bağımlılıkları yükle:
   ```bash
   npm install
   ```

2. `.env.example` dosyasını `.env` olarak kopyala ve kendi Anthropic API anahtarını gir:
   ```bash
   cp .env.example .env
   ```
   `.env` içine API anahtarını yaz:
   ```
   ANTHROPIC_API_KEY=sk-ant-xxxxxxx
   ```
   API anahtarını https://console.anthropic.com/ adresinden alabilirsin.

3. Sunucuyu başlat:
   ```bash
   npm start
   ```

4. Tarayıcıda aç: http://localhost:3000

## GitHub'a Yükleme

Proje klasöründe terminalde şu adımları izle:

```bash
git init
git add .
git commit -m "İlk commit: AI web asistanı"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADIN/REPO_ADI.git
git push -u origin main
```

> `.gitignore` dosyası `.env` ve `node_modules/` klasörünü otomatik olarak hariç tutar, yani API anahtarın GitHub'a gitmez.

## Proje Yapısı

```
ai-web-assistant/
├── server/
│   └── index.js        # Express backend, Claude API'ye istek atar
├── public/
│   ├── index.html       # Sohbet arayüzü
│   ├── style.css
│   └── script.js
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

## Notlar

- Konuşma geçmişi şu an sunucu belleğinde (RAM) tutuluyor — sunucu yeniden başlarsa geçmiş silinir. Kalıcı hale getirmek için bir veritabanı (örn. SQLite, MongoDB) eklenebilir.
- `CLAUDE_MODEL` değişkeniyle `.env` dosyasından farklı bir model seçebilirsin.
- Production'a çıkmadan önce: rate limiting, kullanıcı bazlı oturum yönetimi ve hata izleme (logging) eklenmesi önerilir.
